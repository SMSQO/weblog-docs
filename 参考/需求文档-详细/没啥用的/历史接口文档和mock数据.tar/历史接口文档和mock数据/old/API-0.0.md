# 个人博客API文档

## 0. 一些类型

这些类型是后面定义接口时会需要用到的. 采用类似于typescript的伪码写成.
```typescript
type URL = string

// 即用户, 即注册用户. 无论在用例中的身份如何, 都叫它Blogger.
type BloggerInfo = {
    id:         long
    name:       string
    avatarUrl:  string
    contact:    string  // 手机号
    email:      string
    graduate:   string  // 毕业院校
}

// 参考个人博客主页设计图. 这里描述了图里的一些信息
type BlogInfo = {
    blogger:    BloggerInfo
    visitCount: long    // 此个人主页被访问的次数
    likeCount:  int
    fans:       int     // 当前用户有多少人关注(follow)

    blogCount:  int
    blogsUrl:   URL
}

type PostInfo = {
    id:         long

    title:      string
    content:    string

    author:     BloggerInfo 
    tags:       TagInfo[]
    avatar:     URL | null
    permission: {
        isPublic:           boolean // 是否公开
        needReviewComment:  boolean // 是否需要审核评论
    }
    visits:             long    // 博客被访问的次数
    unreviewedCount:    int     // 没有审核过的评论的数量
}

type TagInfo = {
    id:             long
    name:           string
    owner:          BloggerInfo
    description:    string
}

type CommentInfo = {
    id:             long
    author:         BloggerInfo
    content:        string
    post:           URL 
    replyTo:        CommentInfo | null
    reviewPassed:   boolean
}

type AttachmentInfo = {
    id:             long
    name:           string  // 文件名
    url:            URL
    owner:          BloggerInfo
    filesize:       int     // 以B为单位
}
```

## 1. 博客管理部分 (created: 李景涛)

这一部分主要是针对个人主页界面的. 所以在阅读时最好参考"需求分析-概要.pdf"中个人主页部分的设计图.

| 方法  | 接口              | 参数                              | 返回        | 描述                           |
|-------|-------------------|-----------------------------------|-------------|--------------------------------|
| GET   | /blogger/{id}     | id: long                          | BloggerInfo | 查询个人简介(不包括博客的信息) |
| PATCH | /blogger/{id}     | info: UserInfo                    | -           | 修改个人简介                   |
| GET   | /blog/{id}        | id: long                          | BlogInfo    | 查看个人博客数据               |
| GET   | /blog/{id}/posts  | id: long, page: int, perpage: int | PostInfo[]  | 查看个人全部博文               |
| POST  | /blog/{id}/like   | id: long                          | -           | 点赞当前博客                   |
| GET   | /blogger/{id}/tag | id: long                          | TagInfo[]   | 查看个人定义的博文标签         |

## 2.  评论模块 (created: 李景涛)

| 方法   | 接口                      | 参数                                            | 返回          | 描述                                             |
|--------|---------------------------|-------------------------------------------------|---------------|--------------------------------------------------|
| GET    | /post/{id}/comment        | id: long, all: boolean, page: int, perpage: int | CommentInfo[] | 返回评论列表; all设置为false时只返回未审核的评论 |
| POST   | /post/{id}/comment        | id: long, comment: CommentInfo                  | -             | 添加评论                                         |
| DELETE | /post/comment/{id}        | id: long                                          | -             | 删除评论                                         |
| GET    | /mail/{id}/unread-comment | id: long, page: int, perpage: int               | CommentInfo[] | 获取未读评论                                     |


## 3. 登录/注册模块 (created: 李国昌)

| 方法 | 接口              | 参数                                                           | 返回 | 描述 |
|------|-------------------|----------------------------------------------------------------|------|------|
| POST | /blogger/register | name: string, password: string, contact: string, email: string | -    | 注册 |
| POST | /blogger/login    | contact: string, password: string                              | -    | 登录 |


## 4. 订阅模块 (created: 李国昌)

| 方法 | 接口                     | 参数                        | 返回 | 描述                                           |
|------|--------------------------|-----------------------------|------|------------------------------------------------|
| POST | /blogger/{id}/subsribe   | id: long, subsriberId: long | -    | 订阅博主. id是被订阅人的, subscriber是订阅者的 |
| POST | /blogger/{id}/unsubsribe | id: long, subsriberId: long | -    | 取消订阅                                       |



## 5. 博客管理 (created: 张宇)

| 方法 | 接口 | 参数 | 返回 | 描述 |
|------|------|------|------|------|

> 我感觉这些接口都用不到, 这里就不写了. 

> 查看个人主页包括查看最近编辑博文，查看推荐博文等
> 查看个人中心包括编辑博文，附件管理等
> 基于推荐算法推荐博文
> 基于选取规则搜索博文

## 6. 博客管理2 (created: 徐海洲)

| 方法  | 接口                             | 参数                    | 返回     | 描述             |
|-------|----------------------------------|-------------------------|----------|------------------|
| POST  | /post                            | post: PostInfo          | -        | 添加博客         |
| PATCH | /post/{pid}                      | Post: PostInfo          | -        | 修改博客         |
| GET   | /blogger/{uid}/post              | page: int, perpage: int | PostInfo | 获取博主文章列表 |
| POST  | /post/{pid}/comment/{cid}/review | pass: boolean           | -        | 审核评论         |

## 7. 标签/附件管理 (create: 徐海洲)

| 方法   | 接口                            | 参数                     | 返回             | 描述         |
|--------|---------------------------------|--------------------------|------------------|--------------|
| POST   | /blogger/{uid}/tag/{tid}        | tag: TagInfo             | -                | 修改标签信息 |
| DELETE | /blogger/{uid}/tag/{tid}        | -                        | -                | 删除标签     |
| GET    | /blogger/{uid}/attachment       | page: int, perpage: int  | AttachmentInfo[] | 查询附件列表 |
| POST   | /blogger/{uid}/attachment       | name: string, file: File | AttachmentInfo   | 上传附件     |
| DELETE | /blogger/{uid}/attachment/{aid} | -                        | -                | 删除附件     |
